# DJ👟 - Site estático (template)

Este repositório contém um site estático simples para a loja **DJ👟**. Você pode usar este template para publicar no GitHub Pages.

## Conteúdo
- `index.html` - Página principal
- `styles.css` - Estilos
- `README.md` - Este arquivo
- `LICENSE` - Licença MIT
- `.gitignore` - Ignorar arquivos locais

## Como publicar no GitHub (passo a passo)
1. Crie um repositório no GitHub chamado `dj-sneakers-site` (ou outro nome de sua escolha).
2. No seu computador:
```bash
git init
git add .
git commit -m "Primeiro commit - site DJ"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/dj-sneakers-site.git
git push -u origin main
```
3. No GitHub, vá em **Settings > Pages** e escolha a branch `main` e `/ (root)` como pasta. Salve. Em poucos minutos seu site estará disponível em `https://SEU_USUARIO.github.io/dj-sneakers-site/`.

## Personalização
- Substitua as caixas "Imagem" por imagens reais em uma pasta `assets/`.
- Atualize contatos no rodapé.
- Para um site dinâmico, converta para React/Vite ou outro framework.

## Dúvidas
Se quiser, eu posso gerar também uma versão em React (Vite) pronta para GitHub — me avise.
